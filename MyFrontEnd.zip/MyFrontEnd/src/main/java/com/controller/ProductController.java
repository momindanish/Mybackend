package com.controller;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
////import java.io.FileOutputStream;
//import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.niit.dao.CategoryDAO;
import com.niit.dao.ProductDAO;
import com.niit.model.Category;
import com.niit.model.Product;

@Controller
public class ProductController 
{
	
	 @RequestMapping("/Product1")
	 public String showCategoryPage()
	 {
	 return "product";
	 }
	
	
    // private static final int ProductId = 0;
	//private static final String ProductName = null;
	//private static final String ProductDiscription = null;
	@Autowired
	ProductDAO prod1;
//	
	@Autowired
	CategoryDAO categoryDAO;
//	
	@RequestMapping("/product1")
	public String showproduct(Model m)
	{
		//Product prod=new Product();
		//m.addAttribute("prod",prod);
		List<Product> ListproductDAO=prod1.listProduct();
		m.addAttribute("productList",ListproductDAO);
		List<Category> ListCategory=categoryDAO.listCategories();
		//m.addAttribute("ListCategory",this.getCategory(ListCategory));
		//m.addAttribute("userClickProduct",true);
		return "product";
	}

	
	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
	public String addProductDetail(@RequestParam("productName") String productName,
			@RequestParam("productDiscription") String productDiscription,@RequestParam("categoryId") int categoryId,@RequestParam("price") int price,@RequestParam("stock") int stock,@RequestParam("image") MultipartFile images,Model m)
	{
		Product prod = new Product();
		//prod.setProductId(productId);
		prod.setProductName(productName);
		prod.setProductDiscription(productDiscription);
		prod.setCategoryId(categoryId);
		prod.setPrice(price);
		prod.setStock(stock);
		prod.setImage(images);
		prod1.add(prod);
		String path="C:\\Users\\mruser\\Desktop\\Danish\\MyFrontEnd\\src\\main\\webapp\\resources\\images\\";
		path=path+String.valueOf(prod.getProductId())+".jpg";
		
		File imagefile=new File(path);
		if(!images.isEmpty())
		{
			try
			{
				byte[] buffer=images.getBytes();
				FileOutputStream fos=new FileOutputStream(imagefile);
				BufferedOutputStream bs=new BufferedOutputStream(fos);
				bs.write(buffer);
				bs.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
				m.addAttribute("Error","Exception Occured during the Image Uploading"+e);	
			}
		}
		else
		{
			System.out.println("error occured");
			m.addAttribute("Error","Error Occured during the Image Uploading");
		}
		Product prod2=new Product();
		m.addAttribute("prod", prod2);
	
//	@RequestMapping(value="/InsertProduct",method=RequestMethod.POST)
//	public String insertProduct(@ModelAttribute("prod")Product prod,@RequestParam("image")MultipartFile prodImage,Model m)
//	
//	{
//		
//		ProductDAO.addProduct(product);
//		
//String path="C:\\Users\\mruser\\Desktop\\Danish\\MyFrontEnd\\src\\main\\webapp\\resources\\images";
//		
//		String path1=path+String.valueOf(prod.getProductId())+".jpg";
//		
//		File imagefile=new File(path1);
//		if(!prodImage.isEmpty())
//		{
//			try
//			{
//				byte[] buffer=prodImage.getBytes();
//				FileOutputStream fos=new FileOutputStream(imagefile);
//				BufferedOutputStream bs=new BufferedOutputStream(fos);
//				bs.write(buffer);
//				bs.close();
//			}
//			catch(Exception e)
//			{
//				System.out.println(e);
//				m.addAttribute("Error","Exception Occured during the Image Uploading"+e);	
//			}
//		}
//		else
//		{
//			System.out.println("error occured");
//			m.addAttribute("Error","Error Occured during the Image Uploading");
//		}
//		Product prod1=new Product();
//		m.addAttribute("prod", prod1);
////		
//		List<Product> ListproductDAO = prod1.
//		m.addAttribute("productList",ListproductDAO);
//	
//////		List<Category> ListCategory=categoryDAO.listCategories();
//////		m.addAttribute("ListCategory",this.getCategoryList(ListCategory));
//		return "Product";
//	}
//
//	@RequestMapping(value = "/deleteProduct/{productid}")
//	public String deletProduct(@PathVariable("productid") int productid, Model m)
//	{
//		Product prod = productDAO.getProduct(productid);
//		productDAO.delete(prod);
//
//		List<Product> ListproductDAO = productDAO.listProduct();
//		// binding the listcategoryDAO and sending to jsp page
//		m.addAttribute("ListproductDAO", ListproductDAO);
		
		List<Product> ListproductDAO=prod1.listProduct();
		m.addAttribute("productList",ListproductDAO);
		
		
		
		
		return "product";
}
//	
    /*@RequestMapping(value="/editProduct/{productid}")
	public String editProduct(@PathVariable("productid")int productid,Model m)
	{
		Product prod=productDAO.getProduct(productid);
		m.addAttribute("prod",prod);
		
		List<Product> productList=productDAO.listProduct();
		m.addAttribute("productList", productList);
////		
		List<Category> ListCategory=categoryDAO.listCategories();
		m.addAttribute("productList",this.getCategoryList(ListCategory));
		return "editProduct";
	}*/
//
//	@RequestMapping(value="/UpdateProduct",method=RequestMethod.POST)
//	public String updateProduct(@RequestParam("productid") int productid,
//			@RequestParam("productName") String productName, @RequestParam("productDiscription") String productDiscription,
//			Model m, String ProductName, String ProductDiscription) 
//	{
//		Product prod = productDAO.getProduct(productid);
//
//		prod.setProductName(ProductName);
//		prod.setProductDiscription(ProductDiscription);
//		productDAO.update(prod);
//
//		//System.out.println("Two");
//		List<Product> ListproductDAO=productDAO.listProduct();
//		m.addAttribute("ListproductDAO", ListproductDAO);
//		
////		List<Category> ListCategory=categoryDAO.listCategories();
////		m.addAttribute("ListCategory",this.getCategoryList(ListCategory));
//		return "product";
//	}
//
	@RequestMapping(value="/updateProduct/{productId}")
	public String updateProduct(@PathVariable("productId")int productId,@RequestParam("price")int price,@RequestParam("stock")int stock,Model m)
	{
		Product prod2=prod1.getProduct(productId);
		
		prod2.setPrice(price);
		prod2.setStock(stock);		
		prod1.update(prod2);
//		
		//Product prod1=new Product();
		//m.addAttribute("prod",prod1);
//		
//		
		List<Product> ListproductsDAO= prod1.listProduct();
		m.addAttribute("productList", ListproductsDAO);
//		
		return "product";
	}
//
	@RequestMapping(value="/deleteProduct/{productid}")
	public String deleteProduct(@PathVariable("productid")int productid,Model m)
	{
		Product prod=prod1.getProduct(productid);
		prod1.delete(prod);
		
		//Product prod1=new Product();
	//	m.addAttribute("prod",prod1);
//		
		List<Product> ListProducts=prod1.listProduct();
		m.addAttribute("productList", ListProducts);
		
		/*List<Category> ListCategory=categoryDAO.listCategories();
		m.addAttribute("ListCategory",this.getCategoryList(ListCategory));*/
//		
		return "product";
	}
//
//	public LinkedHashMap<Integer,String> getProductList(List<Product> listProduct)
//	{
//		LinkedHashMap<Integer,String> productData=new LinkedHashMap<Integer,String>();
//		
//		int count=0;
//		while(count <listProduct.size())
//		{
//			productData.put(listProduct.get(count).getProductId(),listProduct.get(count).getProductName());
//			count++;
//		}
//		return productData;
//	}
}
