package com.controller;

import java.util.Collection;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.net.jsse.openssl.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.dao.UserDAO;
import com.niit.model.User;

@Controller
public class UserController
{
	@Autowired
	UserDAO udao;
	
	/*@Autowired
	private BCryptPasswordEncoder passwordEncoder;*/
	
	boolean flag=true;
	
	/*@RequestMapping(value="/login")*/
/*	public String loginSuccess(HttpSession session,Model m)
	{
		String page="";
		SecurityContext securityContext=SecurityContextHolder.getContext();
		Authentication authentication=securityContext.getAuthentication();
		
		String username=authentication.getName();
		
		Collection<GrantedAuthority> roles=(Collection<GrantedAuthority>)authentication.getAuthorities();
		
		for(GrantedAuthority role:roles)
		{
			session.setAttribute("role", role.getAuthority());
			
			if(role.getAuthority().equals("Role_Admin"))
			{
				loggedIn=true;
				page="AdminHome";
				session.setAttribute("loggedIn", loggedIn);
				session.setAttribute("username", username);
			}
			else
			{
				loggedIn=true;
				page="UserHome";
				session.setAttribute("loggedIn", loggedIn);
				session.setAttribute("username", username);
			}
			
		}
		
		return page;
	}
	
	@RequestMapping(value="/login1")
	public String showLoginPage()
	{
		return "login1";
	}
	
	@RequestMapping(value="/forgot")
	public String showForgotPasswordPage()
	{
		return "forgot";
	}	
		boolean loggedIn=false;*/
		
	
	
	
	
	
	@RequestMapping(value="/Register")
	public String showUser(Model m)
	{
		System.out.println("JAva Code");
		 
		return "signup";
	}

	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public String addUserDetail(@RequestParam("userId")int userId,@RequestParam("userName")String userName,@RequestParam("password")String password,
	@RequestParam("role")String role,	
	@RequestParam("customerName")String customerName,
	@RequestParam(" mobileNumber")int mobileNumber,@RequestParam(" emailId")String emailId,@RequestParam("address")String address,Model m)
	{
	User dat=new User();
	dat.setUserId(userId);
	dat.setUserName(userName);
	dat.setPassword(password);
	dat.setRole(role);
	//dat.setPassword(passwordEncoder.encode(dat.getPassword()));
	dat.setCustomerName(customerName);
	dat.setMobileNumber(mobileNumber);
	dat.setEmailId(emailId);
	dat.setAddress(address);
	
	
	udao.add(dat);
	
	return "Register";
	}
}
