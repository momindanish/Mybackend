package com.controller;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

@Controller
public class CategoryController {
	@Autowired
	CategoryDAO categoryDAO;

	// @RequestMapping("/category")
	// public String showCategoryPage()
	// {
	// return "category";
	// }

	@RequestMapping("/category")
	public String showCategory(Model m) {
		System.out.println("JAva Code");
		List<Category> ListcategoryDAO = categoryDAO.listCategories();
		// binding the listcategoryDAO and sending to jsp page
		m.addAttribute("categoryList", ListcategoryDAO);
		return "category";
	}

	@RequestMapping(value = "/addCategory", method = RequestMethod.POST)
	public String addCategoryDetail(@RequestParam("categoryName") String categoryName,
			@RequestParam("categoryDesc") String categoryDesc, Model m)
	{
		Category cat = new Category();
		cat.setCategoryName(categoryName);
		cat.setCategoryDesc(categoryDesc);
		categoryDAO.add(cat);
		List<Category> ListcategoryDAO = categoryDAO.listCategories();
		// binding the listcategoryDAO and sending to jsp page
		m.addAttribute("categoryList", ListcategoryDAO);

		return "category";
	}

	@RequestMapping(value = "/deleteCategory/{categoryid}")
	public String deleteCategory(@PathVariable("categoryid") int categoryid, Model m)
	{
		Category cat1 = categoryDAO.getCategory(categoryid);
		categoryDAO.delete(cat1);

		List<Category> ListcategoryDAO = categoryDAO.listCategories();
		// binding the listcategoryDAO and sending to jsp page
		m.addAttribute("categoryList", ListcategoryDAO);
		return "category";
	}

	//
	@RequestMapping(value = "/editCategory/{categoryid}")
	public String editCategory(@PathVariable("categoryid") int categoryid, Model m) 
	{
		Category cat2 = categoryDAO.getCategory(categoryid);
		m.addAttribute("cat2", cat2);
		return "editCategory";
	}
	//

	@RequestMapping(value = "/updateCategory", method = RequestMethod.POST)
	public String updateCategory(@RequestParam("categoryid") int categoryid,
			@RequestParam("categoryName") String categoryName, @RequestParam("categoryDesc") String categoryDesc,
			Model m) 
	{
		Category cat3 = categoryDAO.getCategory(categoryid);

		cat3.setCategoryName(categoryName);
		cat3.setCategoryDesc(categoryDesc);

		categoryDAO.update(cat3);

		List<Category> ListcategoryDAO = categoryDAO.listCategories();
		// binding the listcategoryDAO and sending to jsp page
		m.addAttribute("ListcategoryDAO", ListcategoryDAO);
		return "index";
	}

	public LinkedHashMap<Integer, String> getCategoryList(List<Category> listCategory) 
	{
		LinkedHashMap<Integer, String> categoryData = new LinkedHashMap<Integer, String>();

		int count = 0;
		while (count < listCategory.size())
		{
			categoryData.put(listCategory.get(count).getCategoryId(), listCategory.get(count).getCategoryName());
			count++;
		}
		return categoryData;
	}
}
