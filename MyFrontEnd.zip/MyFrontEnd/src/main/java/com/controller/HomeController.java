package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class HomeController 
{
	@RequestMapping(value= {"/","/home"})
	public String showHomePage()
	{
	  return "index";
	}
	@RequestMapping("/about")
	public String showAboutPage()
	{
	  return "about";
	}
	@RequestMapping("/contact")
	public String showContactPage()
	{
	  return "contact";
	}
	@RequestMapping("/product")
	public String showProductPage()
	{
	  return "product";
	}
//	@RequestMapping("/category")
//	public String showCategoryPage()
//	{
//	  return "category";
//	}
	@RequestMapping("/login")
	public String showLoginPage()
	{
	  return "login";
	}
}
