package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table
public class Product 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int productId;
	 String productName;
	String productDiscription;
	//int supplier;
	 int categoryId;
   	int price;
	 int stock;
@Transient
private MultipartFile image;
	
	public MultipartFile getImage()
	{
		return image;
	}
	
	
	public void setImage(MultipartFile image) 
	{
		this.image = image;
	}

	public int getProductId()
	{
		return productId;
	}
	
	public void setProductId(int productId)
	{
		this.productId = productId;
	}
	
	public String getProductName()
	{
		return productName;
	}
	
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}
	
	public String getProductDiscription()
	{
		return productDiscription;
	}
	
	public void setProductDiscription(String productDiscription)
	{
		this.productDiscription = productDiscription;
	}
	
	/*public int getSupplier()
	{
		return supplier;
	}
	
	public void setSupplier(int supplier) 
	{
		this.supplier = supplier;
	}*/
	
	public int getCategoryId() 
	{
		return categoryId;
	}
	
	public void setCategoryId(int categoryId)
	{
		this.categoryId = categoryId;
	}
	
	public int getPrice() 
	{
		return price;
	}
	
	public void setPrice(int price)
	{
		this.price = price;
	}
	
	public int getStock()
	{
		return stock;
	}
	
	public void setStock(int stock)
	{
		this.stock = stock;
	}
	
	
}
