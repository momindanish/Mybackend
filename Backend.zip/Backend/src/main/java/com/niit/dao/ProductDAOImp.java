package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Product;
@Repository("ProductDao")
@Transactional
public class ProductDAOImp implements ProductDAO
{
	@Autowired
	SessionFactory sessionFactory;
	
	public ProductDAOImp(SessionFactory sf)
	{
		super();
		this.sessionFactory=sf;
		
	}

	@Override
	public boolean add(Product pd)
	{
		System.out.println("before try");
		try 
		{
			System.out.println("in a try");
			//sessionFactory.openSession().save(pd);
			sessionFactory.getCurrentSession().save(pd);
			System.out.println("return product");
			return true;
			
		}
		catch(Exception e)
		{
			return false;
		}
		
	}

	@Override
	public boolean delete(Product pd)
	{
		try
		{
			sessionFactory.getCurrentSession().delete(pd);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
		
		
	}

	@Override
	public boolean update(Product pd) 
	{
		try
		{
			sessionFactory.getCurrentSession().update(pd);
			return true;
		}
		catch(Exception e)
		{
		return false;
		}
	}

	@Override
	public List<Product> listProduct()
	{
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Product");
		List<Product> listProduct=query.list();
		session.close();
		return listProduct;
				
	}

  
	public Product getProduct(int productId)
	{
		Session session=sessionFactory.openSession();
		Product pd=session.get(Product.class,productId);
		session.close();
		return pd;
	}

	

}
