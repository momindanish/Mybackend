package com.niit.dao;

import java.util.List;

import com.niit.model.User;

public interface UserDAO
{
     public boolean add(User us);
     public boolean delete(User us);
     public boolean update(User us);
     public List<User> listUser();
     public User getUser(int usId);
}
