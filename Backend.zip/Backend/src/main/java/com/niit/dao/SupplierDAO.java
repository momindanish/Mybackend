package com.niit.dao;

import java.util.List;

import com.niit.model.Supplier;


public interface SupplierDAO 
{
	public boolean add(Supplier sp);
	public boolean delete(Supplier sp);
	public boolean update(Supplier sp);
	public List<Supplier> listSupplier();
	public Supplier getSupplier(int spId);
}
