package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

public interface ProductDAO
{
	public boolean add(Product pd);
	public boolean delete(Product pd);
	public boolean update(Product pd);
	public List<Product> listProduct();
	public  Product getProduct(int pdId); 
		
		
	
}
