package com.niit.dao;

import java.util.List;


import javax.transaction.Transactional;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.model.User;
@Repository("repo1")
@Transactional

public class UserDAOImp implements UserDAO 
{
	@Autowired
	SessionFactory sessionFactory;
	public UserDAOImp(SessionFactory sef)
	{
	   this.sessionFactory=sef;
	}
	@Override
	public boolean add(User us)
	{
		try
		{
			sessionFactory.getCurrentSession().save(us);
			return true;
		}
		catch(Exception e)
		{
		  return false;
		}
	}
	@Override
	public boolean delete(User us) 
	{
		try
		{
			sessionFactory.getCurrentSession().delete(us);
			return true;
		}
		catch(Exception e)
		{
		  return false;
		}
		
	}
	@Override
	public boolean update(User us) 
	{
		try
		{
			sessionFactory.getCurrentSession().save(us);
			return true;
		}
		catch(Exception e)
		{
		  return false;
		}
		
	}
	@Override
	public List<User> listUser()
	{
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from User");
		List<User> listUser=query.list();
		session.close();
		return listUser;
	}
	@Override
	public User getUser(int usId) 
	{
		
		Session session=sessionFactory.openSession();
		User us=session.get(User.class,usId);
		session.close();
		return us;
	}
}
