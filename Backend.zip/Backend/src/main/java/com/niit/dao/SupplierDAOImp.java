package com.niit.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.model.Supplier;
@Repository("repo")
@Transactional
public class SupplierDAOImp implements SupplierDAO
{
	@Autowired
	SessionFactory sessionFactory;
	public SupplierDAOImp(SessionFactory sf)
	{
		this.sessionFactory=sf;
	}
	
	@Override
	public boolean add(Supplier sp)
	{
		try 
		{
		   sessionFactory.getCurrentSession().save(sp);	
			return true;
		}
		catch(Exception e)
		{
			return false;	
		}
		
	}

	@Override
	public boolean delete(Supplier sp)
	{
		try
		{
			sessionFactory.getCurrentSession().delete(sp);
		    return true;
		}
		catch(Exception e)
		{
		    return false;
		}
	}

	@Override
	public boolean update(Supplier sp) 
	{
		try
		{
			sessionFactory.getCurrentSession().update(sp);
			return true;
		}
		catch(Exception e)
		{
		    return false;
		}
	}

	@Override
	public List<Supplier> listSupplier()
	{
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("form Supplier");
		List<Supplier> listSupplier=query.list();
		session.close();
		return listSupplier ;
	}

	@Override
	public Supplier getSupplier(int spId)
	{
		Session session=sessionFactory.openSession();
		Supplier sp=session.get(Supplier.class,spId);
		session.close();
		return sp;
	}
	
}
