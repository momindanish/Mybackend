package com.niit.InteriorBackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
        System.out.println("hello1");
        context.scan("com.niit");
        
        System.out.println("hello2");
        context.refresh();
        
        System.out.println("hello3");
        CategoryDAO categoryDao=(CategoryDAO)context.getBean("categoryDAO");
      
        Category category=new Category();
        category.setCategoryName("LG");
        category.setCategoryDesc("LG Mobile");
       
        System.out.println("hello4");
        categoryDao.add(category);
        
    }
}
