package com.ecomm.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;
import com.niit.model.User;

public class UserDAOTestCase 
{
	private static UserDAO uDao;
    @BeforeClass
	public static void executeFirst()
	{
		AnnotationConfigApplicationContext context=new 	AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		uDao=(UserDAO)context.getBean("repo1");
	}
    @Ignore
    @Test
    public void addUser()
    {
    	User use=new User();
    	use.setUserId(2);
    	use.setUserName("ravi");
    	use.setPassword("1234");
    	use.setEnabled(true);
    	use.setRole("salesman");
    	use.setCustomerName("ravi");
    	use.setMobileNumber(123456789);
    	use.setEmailId("rvi.@gmail.com");
    	use.setAddress("mumbai");
    	assertTrue("adding the use",uDao.add(use));
    	
    }
   
    @Test
    public void updateUser()
    {
    	User user=uDao.getUser(37);
    	user.setUserName("samad");
    	
    	assertTrue("problem in updating the user",uDao.update(user));
    }
    @Ignore
    @Test
    public void deleteUser()
    {
    	User user=uDao.getUser(44);
    	user.setUserName("samad");
    	
    	assertTrue("problem in deleting the user",uDao.delete(user));
    }
    @Ignore
    @Test
    public void listUser()
    {
    	List<User> listUser=uDao.listUser();
    	     assertTrue("problem in Listing the user",listUser.size()>0);
    
    	     for(User user:listUser)
    	     {
    	    	 System.out.println("User Id:"+user.getUserId());
    	    	 System.out.println("User name:"+user.getUserName());
    	    	 System.out.println("Password:"+user.getPassword());
    	    	 System.out.println("Role:"+user.getRole());
    	    	 System.out.println("Customer Name:"+user.getCustomerName());
    	    	 System.out.println("Mobile Number:"+user.getMobileNumber());
    	    	 System.out.println("Email Id:"+user.getEmailId());
    	    	 System.out.println("Address:"+user.getAddress());
    	    	 
    	     }
    }
    
    

}
