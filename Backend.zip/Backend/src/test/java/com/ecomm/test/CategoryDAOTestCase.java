package com.ecomm.test;


import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

public class CategoryDAOTestCase
{
	
	private static CategoryDAO categoryDAO;
	
	@BeforeClass
	public static void executeFirst()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit");
		context.refresh();
		
		categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
	}
	
	@Test
	public void addCategoryTest()
	{
		Category category=new Category();
		category.setCategoryName("rado");
		category.setCategoryDesc("Rado watch");
		
		assertTrue("problem in adding the category",categoryDAO.add(category));
	}
	@Ignore
	@Test
	public void updateCategoryTest()
	{
		Category category=categoryDAO.getCategory(4);
		category.setCategoryDesc("Football");
		
		assertTrue("problem in updating the category",categoryDAO.update(category));
	}
	@Ignore
	@Test
	public void deleteCategoryTest()
	{
		Category category=categoryDAO.getCategory(2);
		category.setCategoryDesc("LG mobile");
		
		assertTrue("problem in updating the category",categoryDAO.delete(category));
	}
	@Ignore
	@Test
	public void listCategoryTest()
	{
		List<Category> listcategories=categoryDAO.listCategories();
			assertTrue("problem in Listing the categories",listcategories.size()>0);
		
		for(Category category:listcategories)
		{
			System.out.println("Category ID:"+category.getCategoryId());
			System.out.println("Category Name:"+category.getCategoryName());
			System.out.println("Category Desc:"+category.getCategoryDesc());
		}
	}

}
