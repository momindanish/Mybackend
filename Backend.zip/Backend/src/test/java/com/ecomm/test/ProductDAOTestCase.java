package com.ecomm.test;


import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.dao.ProductDAO;
import com.niit.model.Product;

public class ProductDAOTestCase 
{
	private static ProductDAO productDAO;
	@BeforeClass
	public static void executeFist()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
	
		productDAO=(ProductDAO)context.getBean("ProductDao");
		
	}

	@Test
	public void addProduct()
	{
		Product prod=new Product();
		//prod.setProductId(3);
		prod.setProductName("Honor");
		prod.setProductDiscription("Mobile");
		//prod.setSupplier(700);
		prod.setCategoryId(1);
		prod.setPrice(15000);
		prod.setStock(700);
		
		assertTrue("problem in adding the product",productDAO.add(prod));
		
	}
	@Ignore
	@Test
	public void updateProduct()
	{
		Product product=productDAO.getProduct(1);
		product.setCategoryId(1234);
		
		assertTrue("problem in updating the product",productDAO.update(product));
	}
	@Ignore
	@Test
	public void deleteProduct()
	{
		Product product=productDAO.getProduct(2);
		product.setProductDiscription("note5pro");
		
		assertTrue("problem in updating the product",productDAO.delete(product));
	}
	
	@Test
	public void listProduct()
	{
		List<Product> listProduct=productDAO.listProduct();
		  assertTrue("problem in Listing the product ",listProduct.size()>0);
	
	
	for(Product product:listProduct)
	{
		System.out.println("Product ID:"+product.getProductId());
		System.out.println("Product Name:"+product.getProductName());
		System.out.println("Product Discription:"+product.getProductDiscription());
		//System.out.println("Product Supplier:"+product.getSupplier());
		System.out.println("Product CategoryId:"+product.getCategoryId());
		System.out.println("Product Price:"+product.getPrice());
		System.out.println("Product Stock"+product.getStock());
	}
}
}
