package com.ecomm.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.SupplierDAO;
import com.niit.model.Supplier;

public class SupplierDAOTestCase 
{
	private static SupplierDAO sDao;
	@BeforeClass
	public static void executeFirst()
	{
		AnnotationConfigApplicationContext context=new 	AnnotationConfigApplicationContext(); 
		context.scan("com.niit");
		context.refresh();
		sDao=(SupplierDAO)context.getBean("repo");
	}

	@Test
	public void addSupplier()
	{
		Supplier sup=new Supplier();
		sup.setSupplierId(1);
		sup.setSupplierName("danish");
		sup.setSupplierDiscription("home");
		assertTrue("adding the sup",sDao.add(sup));
	}
	@Ignore
	@Test
	public void updateSupplier()
	{
		Supplier supplier=sDao.getSupplier(2);
		supplier.setSupplierDiscription("flat");
		
		assertTrue("problem in updating the supplier",sDao.update(supplier));
	}
	@Ignore
	@Test
	public void deleteSupplier()
	{
		Supplier supplier=sDao.getSupplier(39);
		supplier.setSupplierDiscription("home");
		
		assertTrue("problem in updating the supplier",sDao.delete(supplier));
	}
	@Ignore
	@Test
	public void listSupplier()
	{
		List<Supplier> listSupplier=sDao.listSupplier();
		  assertNotNull("problem in Listing the supplier ",listSupplier);
	
	
	for(Supplier supplier:listSupplier)
	{
		System.out.println("Supplier ID:"+supplier.supplierId);
		System.out.println("Supplier Name:"+supplier.supplierName);
		System.out.println("Supplier Discription:"+supplier.supplierDiscription);
		
	}
}
}